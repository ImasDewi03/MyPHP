<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
	
<html>
  <head>
    <meta http-equiv="refresh" content="0;url=choose_image.php">
  </head>
  <body>
    <script type="text/javascript">
      <!--
        window.location = 'start.php';
      //-->
    </script>
  </body>
</html>


