<!-- Anastasia Kassari 3130088 -->

<?php
	session_start();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>

	<head>
	
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		
		<title> The Quiz </title>
		
		<link rel="stylesheet" type="text/css" href="style.css">		
		
	</head>
	
	<body>

		<div>
			<img id="logo" src="images/quiz.jpg" alt="Quiz">
		</div>
		
		<div id="start">
			<a href="ask.php">
				<button> Let's Go! </button>
			</a>
		</div>
		
	</body>
	
</html>