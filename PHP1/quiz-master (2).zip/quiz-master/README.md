# PHP Quiz

  Created by: Anastasia Kassari
  
  Date: June 2017
  
  Info: A website with a quiz using PHP. It uses 6 random questions from a MySQL database and counts the time and the right answers for every time a user plays. In order to use an Apache Server, it uses xampp (XAMPP Control Panel v3.2.2) for the Apache server and the MySQL database. (downloaded "xampp-win32-5.6.30-1-VC11.zip" from "https://sourceforge.net/projects/xampp/files/")
  
  P.S.: If the user doesn't pick an answer (multiple choices) then it's considered as a wrong answer. (No default value for radio buttons)
